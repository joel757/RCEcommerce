package com.curso.ecommerce.service;

import com.curso.ecommerce.model.DetalleOrden;

public interface IDetalleOrdenService {
	DetalleOrden save (DetalleOrden detalleOrden);

}
